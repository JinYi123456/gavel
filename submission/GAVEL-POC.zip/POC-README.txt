GAVEL — proof of concept / source bundle
Team HOKKIEN MEE IS RED
Every scam gets a fair trial. The AI investigates — the person decides.

Live deployment: https://gavel-liard.vercel.app

WHAT IS INSIDE
- app/              Next.js app — intake desk, courtroom, gavel, sentencing desk, law school
- lib/engine/       Detection engine — calibrated text classifier (artifacts/), offline URL
                    anatomy, fusion, rules and brand knowledge base, 24-case golden set
- lib/agents/       Officer agents — prosecutor/defence/clerk prompts, the verification
                    gate (validate.ts), and the offline scripted bench (scripted.ts)
- pipeline/         Python training pipeline for the text classifier
- reports/          Evaluation outputs that back the published numbers
- tests/            Test suite, including the 24-case golden set
- scripts/          Live end-to-end check, evaluations, screenshot tooling, deck updater

VERIFY IT (needs Node 20+)
  npm install
  npm test                # engine tests incl. the 24-case golden set (expects 24/24)
  npm run evaluate        # regenerates the runtime metrics in reports/
  npm run dev             # open http://localhost:3000

The app runs without any API key (deterministic mode). Optional model and
transcription integrations read their keys from .env.local (see .env.example);
no keys are included in this bundle.

The courtroom never waits on a model: live drafts get a five-second grace and the
scripted bench takes the floor if they are not ready. Rate limiting is per browser
session, so several judges behind one NAT do not exhaust a shared bucket.
